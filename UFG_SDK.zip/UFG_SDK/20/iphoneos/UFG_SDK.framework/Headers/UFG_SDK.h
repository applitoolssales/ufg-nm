//
//  UFG_SDK.h
//  UFG-SDK
//
//  Created by Clement Barry on 24/08/2020.
//

#import <Foundation/Foundation.h>
@import UIKit;

//! Project version number for UFG_SDK.
FOUNDATION_EXPORT double UFG_SDKVersionNumber;

//! Project version string for UFG_SDK.
FOUNDATION_EXPORT const unsigned char UFG_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UFG_SDK/PublicHeader.h>

@interface UFG_SDK : NSObject

+ (UFG_SDK *)sharedUFG;

- (void)dumpIncludingScreenshot:(UIImage *)screenshot
                          named:(NSString *)name
                    orientation:(UIInterfaceOrientation)orientation
                         traits:(UITraitCollection *)traitCollection
          withCompletionHandler:(void (^)(NSString *result, NSString *name))completionHandler;

@end
